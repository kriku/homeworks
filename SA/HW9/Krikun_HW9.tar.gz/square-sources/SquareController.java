import java.awt.event.*;

public class SquareController {
    private SquareView view;
    private SquareModel model;

    private void performCalculation() {
        String userinput = view.getInput();
        model.setValue(Integer.parseInt(userinput));
        view.setOutput(Integer.toString(model.square()));
    }

    public SquareController(SquareModel model, SquareView view) {
        this.model = model;
        this.view = view;
        // adding listener to the view
        view.addSquareListener(new PerformComputation());
    }

    class PerformComputation implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            performCalculation();
        }
    }
}
