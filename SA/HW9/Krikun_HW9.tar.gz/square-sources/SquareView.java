import javax.swing.*;
import java.awt.event.*;

public class SquareView extends JFrame {
    private JTextField input = new JTextField(5);
    private JTextField output = new JTextField(10);
    private JButton submit = new JButton("Square");

    private SquareModel model;

    public SquareView(SquareModel model) {
        this.model = model;

        // Layout
        JPanel content = new JPanel();
        content.add(input);
        content.add(submit);
        content.add(output);

        this.setContentPane(content);
        this.pack();

        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public String getInput() {
        return input.getText();
    }

    public int getNumber() {
        return Integer.parseInt(getInput());
    }

    public void setOutput(String value) {
        output.setText(value);
    }

    public void setOutput(int value) {
        setOutput(Integer.toString(value));
    }

    public void addSquareListener(ActionListener a) {
        submit.addActionListener(a);
    }
}
